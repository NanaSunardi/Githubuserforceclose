package com.example.a6githubku.favorite

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.a6githubku.data.database.FavoriteUser
import com.example.a6githubku.databinding.ActivityFavoriteBinding

class FavoriteAdapter : RecyclerView.Adapter<FavoriteAdapter.FavoriteViewHolder>() {

    private val list = ArrayList<FavoriteUser>()

    private var onItemClickCallback: OnItemClickCallback? = null
    fun setOnItemClickCallback (onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    fun setList(users: ArrayList<FavoriteUser>) {
        list.clear()
        list.addAll(users)
        notifyDataSetChanged()
    }

    inner class FavoriteViewHolder(val binding: ActivityFavoriteBinding) : RecyclerView.ViewHolder(binding.root){
        fun bind(user: FavoriteUser) {
            binding.root.setOnClickListener {
                onItemClickCallback?.onItemClicked(user)
            }
//
//            binding.apply {
//                Glide.with(itemView)
//                    .load(user.avatar_url)
//                    .transition(DrawableTransitionOptions.withCrossFade())
//                    .centerCrop()
//                    .into(ivUser)
//                tvUsername.text = user.login
//            }
        }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteViewHolder {
        val view = ActivityFavoriteBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FavoriteViewHolder(view)
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(holder: FavoriteViewHolder, position: Int) {
        holder.bind(list[position])
    }
    interface OnItemClickCallback {
        fun onItemClicked(data: FavoriteUser)
    }
}