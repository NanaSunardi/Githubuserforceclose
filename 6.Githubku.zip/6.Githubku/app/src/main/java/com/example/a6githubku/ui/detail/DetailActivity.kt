package com.example.a6githubku.ui.detail

import android.os.Bundle
import android.view.View
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import coil.load
import coil.transform.CircleCropTransformation
import com.dicoding.a6githubku.data.response.GithubkuResponse
import com.dicoding.a6githubku.ui.SectionPagerAdapter
import com.example.a6githubku.R
import com.example.a6githubku.databinding.ActivityDetailBinding
import com.example.a6githubku.ViewModelFactory
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DetailActivity : AppCompatActivity() {
    companion object{
        const val EXTRA_USERNAME = "extra_username"
        const val EXTRA_ID = "extra_id"
        const val EXTRA_URL = "avatar_url"                        // 15/07/24
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_1,
            R.string.tab_2
        )
    }

    private lateinit var binding: ActivityDetailBinding
    private lateinit var viewModel: DetailViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //Utk list followers & following
        val username = intent.getStringExtra(EXTRA_USERNAME)
        val bundle = Bundle()
        bundle.putString(EXTRA_USERNAME, username)
        val id = intent.getIntExtra(EXTRA_ID, 0)
        val avatarUrl = intent.getIntExtra(EXTRA_URL, 0)     // 15/07/24

        // Utk Viewpager
        val sectionPagerAdapter = SectionPagerAdapter(this, username.toString())  // untuk menghubungkan SectionsPagerAdapter dengan ViewPager2
        val viewPager: ViewPager2 = findViewById(R.id.view_pager)
        viewPager.adapter = sectionPagerAdapter
        val tabs: TabLayout = findViewById(R.id.tabs)
        TabLayoutMediator(tabs, viewPager) { tab, position ->   // Dengan menerapkan TabLayoutMediator, maka Fragment yang tampil pada ViewPager2 akan sesuai dengan posisi yang dipilih pada tab
            tab.text = resources.getString(TAB_TITLES[position]) // Menentukan judul dari masing-masing Tab dengan menggunakan TAB_TITLE yang diambil sesuai dengan urutan posisinya
        }.attach()

        // ViewModelFactory utk menyimpan data favrite
        viewModel = ViewModelProvider(this, ViewModelFactory.getInstance(application)).get(DetailViewModel::class.java)

        // Utk ProgressBar
        viewModel.isLoading.observe(this){
            showLoading(it)
        }

        // Utk tampilan DetailActivity
        viewModel.userDetail(username.toString())
        viewModel._items.observe(this) {
            if (it != null) {
                binding.apply {
                    tvName.text = it.name
                    tvUsername.text = it.login
                    tvFollowers.text = "${it.followers} Followers"
                    tvFollowing.text = "${it.following} Following"
                    binding.ivProfile.load(it.avatar_url) {
                        transformations(CircleCropTransformation())
                    }
                }
            }
        }

        // Utk menyimpan data favorite
        var _isChecked = false
        CoroutineScope(Dispatchers.IO).launch {
            val count = viewModel.checkUser(id)
            withContext(Dispatchers.Main){
                if (count != null){
                    if ( count>0 ){
                        binding.toggleFavorite.isChecked = true
                        _isChecked = true
                    }else{
                        binding.toggleFavorite.isChecked = false
                        _isChecked = false
                    }
                }
            }
        }
        binding.toggleFavorite.setOnClickListener{
            _isChecked =!_isChecked
            if (_isChecked){
//                viewModel.addToFavorite(username.toString(), id)
                viewModel.addToFavorite(username.toString(), id, avatarUrl.toString())    // 15/07/24
            }else {
                viewModel.removeFromFavorite(id)
            }
            binding.toggleFavorite.isChecked = _isChecked
        }

// Utk ProgressBar
    }
    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }
}