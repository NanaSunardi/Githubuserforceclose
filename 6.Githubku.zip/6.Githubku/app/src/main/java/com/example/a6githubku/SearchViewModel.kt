package com.dicoding.a6githubku.ui

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.a6githubku.data.response.GithubkuResponse
import com.dicoding.a6githubku.data.response.ItemsItem
import com.dicoding.a6githubku.data.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SearchViewModel: ViewModel() {

    private val _items = MutableLiveData<List<ItemsItem>>()
    val items: LiveData<List<ItemsItem>> = _items

    private val _isloading = MutableLiveData<Boolean>()

    companion object {
        private const val TAG = "SearchViewModel"
    }

    fun searchUser(username: String) {
        _isloading.value = true
        val client = ApiConfig.getApiService().getSearchResult(username)
        client.enqueue(object : Callback<GithubkuResponse> {
            override fun onResponse(
                call: Call<GithubkuResponse>,
                response: Response<GithubkuResponse>
            ) {
                _isloading.value = false
                if (response.isSuccessful) {
                    _items.value = response.body()?.items
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<GithubkuResponse>, t: Throwable) {
                _isloading.value = false
                Log.e(TAG, "onFailure: ${t.message.toString()}")
            }
        })
    }
}