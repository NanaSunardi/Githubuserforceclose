//package com.example.a5githubku.data.database
//
//import android.view.LayoutInflater
//import android.view.View
//import android.view.ViewGroup
//import android.widget.TextView
//import androidx.recyclerview.widget.RecyclerView
//import com.example.a6githubku.R
//import com.example.a6githubku.data.database.FavoriteUser
//
//class FavoriteUserAdapter(var list: List<FavoriteUser>): RecyclerView.Adapter<FavoriteUserAdapter.ViewHolder>() {
//
//    class ViewHolder(view: View): RecyclerView.ViewHolder(view) {
//        var username: TextView
//        var avatarUrl: TextView
//        init {
//            username = view.findViewById(R.id.tvItem)
//            avatarUrl = view.findViewById(R.id.img_item_photo)
//        }
//    }
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
//        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.activity_favorite, parent, false)
//        return ViewHolder(view)
//    }
//
//    override fun getItemCount(): Int {
//        return list.size
//    }
//
//    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
//        holder.username.text = list[position].login
//        holder.avatarUrl.text = list[position].avatar_url
//    }
//}